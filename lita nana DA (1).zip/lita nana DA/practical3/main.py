from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('form.html')

@app.route('/submit', methods=['GET', 'POST'])
def submit():
    if request.method == 'POST':
        name = request.form.get('username')
        return f"Hello, {name}! (POST)"
    else:
        return "Use the form to submit data. (GET)"

if __name__ == '__main__':
    app.run(debug=True)
