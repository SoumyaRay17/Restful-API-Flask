from flask import Blueprint, render_template, request, redirect, url_for

auth_bp = Blueprint('auth_bp', __name__, template_folder='../templates')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        return f"<h1>Logged in as {username}</h1>"
    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    return "<h1>You have been logged out</h1>"
