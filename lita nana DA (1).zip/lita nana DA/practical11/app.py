from flask import Flask
from auth.routes import auth_bp  # Import the Blueprint

app = Flask(__name__)
app.secret_key = "your_secret_key"

# Register the blueprint
app.register_blueprint(auth_bp, url_prefix='/auth')

@app.route('/')
def home():
    return '<h1>Home Page</h1>'

if __name__ == '__main__':
    app.run(debug=True)
