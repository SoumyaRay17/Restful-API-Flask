from flask import Flask, session, redirect, url_for, request, render_template

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Required for session security

@app.route('/')
def index():
    username = session.get('username')
    if username:
        return f"<h1>Welcome back, {username}!</h1><a href='/logout'>Logout</a>"
    return '<h1>You are not logged in</h1><a href="/login">Login</a>'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        session['username'] = request.form['username']
        return redirect(url_for('index'))
    return '''
        <form method="POST">
            <input type="text" name="username" placeholder="Enter username">
            <button type="submit">Login</button>
        </form>
    '''

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
