from flask import Flask, redirect, url_for

app = Flask(__name__)


@app.route('/')
def home():
    return '<h1>Home Page</h1><a href="/go-to-about">Go to About</a>'


@app.route('/go-to-about')
def go_to_about():
    # Redirect to the "about" route
    return redirect(url_for('about'))


@app.route('/about')
def about():
    return '<h1>This is the About Page</h1>'


if __name__ == '__main__':
    app.run(debug=True)
