from flask import Flask, redirect, url_for, request

app = Flask(__name__)

@app.route('/')
def home():
    # Redirect to /greet with a query parameter ?name=Alice
    return redirect(url_for('greet', name='Alice'))

@app.route('/greet')
def greet():
    # Get the query parameter from the URL
    name = request.args.get('name', 'Guest')
    return f'<h1>Hello, {name}!</h1>'

if __name__ == '__main__':
    app.run(debug=True)
