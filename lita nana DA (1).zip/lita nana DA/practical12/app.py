from flask import Flask, render_template

app = Flask(__name__)

# Define a custom filter: reverse and capitalize a word
def reverse_and_upper(s):
    return s[::-1].upper()

# Register the filter with Jinja
app.jinja_env.filters['revupper'] = reverse_and_upper

@app.route('/')
def home():
    name = "flask"
    return render_template('index.html', name=name)

if __name__ == '__main__':
    app.run(debug=True)
