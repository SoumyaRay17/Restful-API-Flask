from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>Welcome to the Home Page</h1>'

@app.route('/cause-error')
def cause_error():
    # This will trigger a 500 Internal Server Error
    return 1 / 0

# 🔴 404 Error Handler (Page Not Found)
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

# 🔴 500 Error Handler (Internal Server Error)
@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True)
