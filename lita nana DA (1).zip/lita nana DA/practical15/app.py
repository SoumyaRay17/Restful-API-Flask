from flask import Flask

app = Flask(__name__)

# Route with a dynamic parameter <username>
@app.route('/user/<username>')
def show_user(username):
    return f"<h1>Hello, {username}!</h1>"

# Route with integer parameter <int:id>
@app.route('/post/<int:id>')
def show_post(id):
    return f"<h1>Post ID: {id}</h1>"

if __name__ == '__main__':
    app.run(debug=True)
